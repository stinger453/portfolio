# tags i dont know

**<sup>**

The <sup> tag defines superscript text. Superscript text appears half a character above the normal line, and is sometimes rendered in a smaller font.

**,<Track>**

This element is used to specify subtitles, caption files or other files containing text, that should be visible when the media is playing.

**<bdi>**

this tag isolates a part of text that might be formatted in a different direction from other text outside it.

**<cite>**

Defines the title of a work

**<kbd>**

Defines keyboard input

**<ruby>**

Defines a ruby annotation (for East Asian typography)

**<s>**

Defines text that is no longer correct

**<map>**

Defines a client-side image map

**<embed>**

Defines a container for an external (non-HTML) application

**<bdo>**

Overrides the current text direction

**<blockquote>**

Defines a section that is quoted from another source

**<fieldset>**

Groups related elements in a form

**<legend>**

Defines a caption for a <fieldset> element

**<textarea>**

Defines a multiline input control (text area)

<iframe>

An inline frame is used to embed another document within the current HTML document.